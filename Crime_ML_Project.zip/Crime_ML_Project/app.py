import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix
)


# ============================================================
# 1. PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="South Africa Crime Analytics",
    page_icon="🚔",
    layout="wide"
)


# ============================================================
# 2. TITLE & HEADER
# ============================================================

st.title("🚔 South Africa Crime Analytics")
st.subheader("Machine Learning Classification of Crime Hotspots")

st.write(
    "This dashboard uses South African crime statistics to explore "
    "crime trends and classify crime observations as hotspots or "
    "non-hotspots."
)


# ============================================================
# 3. LOAD DATASET
# ============================================================

@st.cache_data
def load_data():
    return pd.read_csv("SouthAfricaCrimeStats_v2.csv")


df = load_data()


# ============================================================
# 4. DASHBOARD FILTERS (SIDEBAR)
# ============================================================

st.sidebar.header("Dashboard Filters")

# Province filter
provinces = sorted(df["Province"].dropna().unique())
selected_province = st.sidebar.selectbox(
    "Select Province",
    ["All Provinces"] + list(provinces)
)

# Crime category filter
categories = sorted(df["Category"].dropna().unique())
selected_category = st.sidebar.selectbox(
    "Select Crime Category",
    ["All Categories"] + list(categories)
)


# ============================================================
# 5. FILTER DATA FOR VISUALIZATIONS
# ============================================================

filtered_df = df.copy()

if selected_province != "All Provinces":
    filtered_df = filtered_df[filtered_df["Province"] == selected_province]

if selected_category != "All Categories":
    filtered_df = filtered_df[filtered_df["Category"] == selected_category]


# ============================================================
# 6. YEAR COLUMNS
# ============================================================

year_columns = [
    "2005-2006", "2006-2007", "2007-2008", "2008-2009",
    "2009-2010", "2010-2011", "2011-2012", "2012-2013",
    "2013-2014", "2014-2015", "2015-2016"
]


# ============================================================
# 7. DATASET SUMMARY
# ============================================================

st.header("Dataset Summary")

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.metric("Total Records", f"{filtered_df.shape[0]:,}")

with col2:
    st.metric("Crime Categories", filtered_df["Category"].nunique())

with col3:
    st.metric("Police Stations", filtered_df["Station"].nunique())

with col4:
    st.metric("Provinces", filtered_df["Province"].nunique())


# ============================================================
# 8. DISPLAY DATA PREVIEW
# ============================================================

st.header("Crime Dataset Preview")
st.dataframe(filtered_df.head(50), use_container_width=True)


# ============================================================
# 9. CRIME TREND VISUALIZATION
# ============================================================

st.header("Crime Trend Over Time")

year_totals = filtered_df[year_columns].sum()

fig, ax = plt.subplots(figsize=(12, 5))
ax.plot(year_totals.index, year_totals.values, marker="o", color="#1f77b4", linewidth=2)
ax.set_title("Crime Trend Over Time")
ax.set_xlabel("Year")
ax.set_ylabel("Number of Crime Incidents")
plt.xticks(rotation=45)
plt.tight_layout()

st.pyplot(fig)


# ============================================================
# 10. TOP CRIME CATEGORIES VISUALIZATION
# ============================================================

st.header("Crime Category Analysis")

category_totals = (
    filtered_df[year_columns]
    .sum(axis=1)
    .groupby(filtered_df["Category"])
    .sum()
    .sort_values(ascending=False)
    .head(10)
)

fig, ax = plt.subplots(figsize=(10, 5))
category_totals.sort_values().plot(kind="barh", ax=ax, color="#1f77b4")
ax.set_title("Top 10 Crime Categories")
ax.set_xlabel("Number of Incidents")
ax.set_ylabel("Crime Category")
plt.tight_layout()

st.pyplot(fig)


# ============================================================
# 11–17. CACHED MODEL TRAINING (MEMORY-SAFE)
# ============================================================

@st.cache_data
def train_hotspot_model(raw_df):
    # Reshape wide format to long format
    df_long = raw_df.melt(
        id_vars=["Province", "Station", "Category"],
        var_name="Year",
        value_name="Crime_Count"
    )

    # Calculate 75th percentile threshold
    threshold = df_long["Crime_Count"].quantile(0.75)
    df_long["Hotspot"] = (df_long["Crime_Count"] >= threshold).astype(int)

    # Encodes Province, Category, and Year (Excludes Station to avoid RAM overflow)
    X = pd.get_dummies(
        df_long[["Province", "Category", "Year"]],
        drop_first=True
    )
    y = df_long["Hotspot"]

    # Stratified Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.20, random_state=42, stratify=y
    )

    # Train Decision Tree
    clf = DecisionTreeClassifier(random_state=42)
    clf.fit(X_train, y_train)

    return clf, X, X_train, X_test, y_train, y_test, threshold, df_long


# Train model using full original dataset
model, X, X_train, X_test, y_train, y_test, threshold, df_long = train_hotspot_model(df)

# Generate test predictions
y_pred = model.predict(X_test)
accuracy = accuracy_score(y_test, y_pred)


# ============================================================
# 18. MODEL PERFORMANCE METRICS
# ============================================================

st.header("Crime Hotspot Classification")

st.write(f"Hotspot threshold: **{threshold:,.0f} crime incidents**")
st.write(
    "An observation is classified as a hotspot when its crime count "
    "is at or above the 75th percentile."
)

st.subheader("Model Performance")

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Model Accuracy", f"{accuracy:.2%}")
with col2:
    st.metric("Training Records", f"{len(X_train):,}")
with col3:
    st.metric("Testing Records", f"{len(X_test):,}")


# ============================================================
# 19. CLASSIFICATION REPORT
# ============================================================

st.subheader("Classification Report")

report = classification_report(y_test, y_pred, output_dict=True)
report_df = pd.DataFrame(report).transpose()
st.dataframe(report_df.round(3), use_container_width=True)


# ============================================================
# 20. CONFUSION MATRIX & FEATURE IMPORTANCE
# ============================================================

col_cm, col_fi = st.columns(2)

with col_cm:
    st.subheader("Confusion Matrix")
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(6, 5))
    sns.heatmap(
        cm,
        annot=True,
        fmt="d",
        cmap="Blues",
        ax=ax,
        xticklabels=['Non-Hotspot', 'Hotspot'],
        yticklabels=['Non-Hotspot', 'Hotspot']
    )
    ax.set_xlabel("Predicted")
    ax.set_ylabel("Actual")
    ax.set_title("Crime Hotspot Confusion Matrix")
    plt.tight_layout()
    st.pyplot(fig)

with col_fi:
    st.subheader("Top Feature Importances")
    importances = pd.Series(model.feature_importances_, index=X.columns)
    top_10 = importances.sort_values(ascending=False).head(10)

    fig, ax = plt.subplots(figsize=(6, 5))
    sns.barplot(x=top_10.values, y=top_10.index, palette="Blues_r", ax=ax)
    ax.set_title("Top 10 Feature Importances")
    ax.set_xlabel("Gini Importance Score")
    plt.tight_layout()
    st.pyplot(fig)


# ============================================================
# 21. HOTSPOT DISTRIBUTION
# ============================================================

st.subheader("Hotspot Distribution")

hotspot_counts = df_long["Hotspot"].value_counts().sort_index()
hotspot_counts.index = ["Non-Hotspot", "Hotspot"]

fig, ax = plt.subplots(figsize=(7, 4))
hotspot_counts.plot(kind="bar", ax=ax, color=["#1f77b4", "#ff7f0e"])
ax.set_title("Crime Hotspot Distribution")
ax.set_xlabel("Classification")
ax.set_ylabel("Number of Records")
plt.xticks(rotation=0)
plt.tight_layout()

st.pyplot(fig)


# ============================================================
# 22. TECHNICAL SUMMARY
# ============================================================

st.header("Technical Summary")

st.write(
    f"""
    **Dataset:** SouthAfricaCrimeStats_v2.csv

    **Classification algorithm:** Decision Tree Classifier

    **Target variable:** Hotspot

    **Hotspot threshold:** 75th percentile ({threshold:,.0f} incidents)

    **Training data:** {len(X_train):,} records

    **Testing data:** {len(X_test):,} records

    **Accuracy:** {accuracy:.2%}

    **Features:** Province, Category, and Year
    """
)


# ============================================================
# 23. NON-TECHNICAL SUMMARY
# ============================================================

st.header("Non-Technical Summary")

if accuracy >= 0.80:
    st.success(
        "The classification model achieved a high accuracy on "
        "the test data. The model can reliably help identify crime "
        "observations that fall into the hotspot category."
    )
elif accuracy >= 0.60:
    st.info(
        "The classification model achieved a moderate accuracy. "
        "The results provide useful context, but the model could be "
        "improved with additional localized features."
    )
else:
    st.warning(
        "The classification model achieved relatively low accuracy. "
        "Additional feature engineering and hyperparameter tuning "
        "may be required."
    )


# ============================================================
# 24. FOOTER
# ============================================================

st.markdown("---")
st.write("South Africa Crime Analytics | Technical Programming 2")