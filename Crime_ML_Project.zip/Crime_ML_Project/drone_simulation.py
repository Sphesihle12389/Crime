import matplotlib.pyplot as plt
grid_size = 10

x = range(grid_size + 1)
y = range(grid_size + 1)

plt.figure(figsize=(8, 8))

for i in x:
    plt.axvline(i)

for j in y:
    plt.axhline(j)

plt.xlim(0, grid_size)
plt.ylim(0, grid_size)

plt.xlabel("X Coordinate")
plt.ylabel("Y Coordinate")
plt.title("Drone Surveillance Grid")

plt.show()
hotspots = [
    (2, 3),
    (7, 8),
    (4, 6),
    (8, 2)
]
x_hotspots = [point[0] for point in hotspots]
y_hotspots = [point[1] for point in hotspots]

plt.figure(figsize=(8, 8))

for i in range(grid_size + 1):
    plt.axvline(i)
    plt.axhline(i)

plt.scatter(
    x_hotspots,
    y_hotspots,
    s=100,
    label="Crime Hotspot"
)

plt.xlim(0, grid_size)
plt.ylim(0, grid_size)

plt.xlabel("X Coordinate")
plt.ylabel("Y Coordinate")
plt.title("Crime Hotspots")

plt.legend()
plt.show()
waypoints = []

for y in range(grid_size + 1):

    if y % 2 == 0:
        for x in range(grid_size + 1):
            waypoints.append((x, y))
    else:
        for x in range(grid_size, -1, -1):
            waypoints.append((x, y))
path_x = [point[0] for point in waypoints]
path_y = [point[1] for point in waypoints]

plt.figure(figsize=(8, 8))

plt.plot(
    path_x,
    path_y,
    marker="."
)

plt.scatter(
    x_hotspots,
    y_hotspots,
    s=100,
    label="Crime Hotspot"
)

plt.xlabel("X Coordinate")
plt.ylabel("Y Coordinate")
plt.title("Drone Lawnmower Path")

plt.legend()
plt.show()