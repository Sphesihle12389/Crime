import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# 1. STEP 1: LOAD DATASET FIRST
df = pd.read_csv("SouthAfricaCrimeStats_v2.csv")

# 2. STEP 2: CONVERT FROM WIDE TO LONG FORMAT
df_long = df.melt(
    id_vars=["Province", "Station", "Category"],
    var_name="Year",
    value_name="Crime_Count"
)

# 3. STEP 3: DEFINE HOTSPOT TARGET (75th Percentile)
threshold = df_long["Crime_Count"].quantile(0.75)
df_long["Hotspot"] = (df_long["Crime_Count"] >= threshold).astype(int)

# 4. STEP 4: ONE-HOT ENCODE FEATURES
# (Using Province, Category, and Year to avoid RAM memory crashes)
X = pd.get_dummies(
    df_long[["Province", "Category", "Year"]],
    drop_first=True
)
y = df_long["Hotspot"]

# 5. STEP 5: SPLIT TRAIN AND TEST SETS
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42,
    stratify=y
)

# 6. STEP 6: INSTANTIATE AND TRAIN MODEL
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)

# 7. STEP 7: MAKE PREDICTIONS & EVALUATE
y_pred = model.predict(X_test)

accuracy = accuracy_score(y_test, y_pred)
print("Model Accuracy:", round(accuracy, 4))

print("\nClassification Report:")
print(classification_report(y_test, y_pred))

print("\nConfusion Matrix:")
print(confusion_matrix(y_test, y_pred))